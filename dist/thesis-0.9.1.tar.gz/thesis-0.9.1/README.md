# 08.00.13 Mathematical and Instrumental Methods of Economics
## Cobb-Douglas Function: Manipulating Datasets & Reproducing Results
- extract
- collect
- plot
- toolkit
- push
- test
